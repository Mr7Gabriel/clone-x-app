import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:twitter/main.dart'; // pastikan nama dan path file ini benar

// void main() {
//   testWidgets('Home icon appears on startup', (WidgetTester tester) async {
//     // Jalankan aplikasi
//     await tester.pumpWidget(const XCloneApp());

//     // Periksa apakah ikon Home ada
//     expect(find.byIcon(Icons.home), findsOneWidget);
//   });
// }
